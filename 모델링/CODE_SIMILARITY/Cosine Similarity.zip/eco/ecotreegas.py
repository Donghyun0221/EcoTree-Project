from DBManager import *

from DBManager import *
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics.pairwise import cosine_similarity

# from ecotree.gunzip import index_df

# 데이터베이스 연결 및 쿼리 수행
mydb = DBManager()

# SQL 쿼리
sql = """
select *
from(SELECT a.plat as plat,
       SUM(a.archarea) AS total_archarea,
       SUM(a.toarea) AS total_toarea,
       MIN(b.structure) AS structure,
       MIN(a.maincdnm) AS maincdnm,
       MIN(b.other_use) AS other_use,
       ROUND(AVG(b.ground_floor), 0) AS ground_floor,
       ROUND(AVG(b.basement_floor), 0) AS basement_floor,
       a.useym as useym,
       AVG(a.useqty) AS useqty
        FROM main_gas_table a, combined_gas b
        WHERE TRIM(a.plat) = TRIM(b.plat)
        AND a.useym = 202307
        GROUP BY a.plat, a.useym
        HAVING COUNT(DISTINCT a.plat) > 0
        ORDER BY a.useym)
"""

def create_matrix(df):
    arr = ['TOTAL_ARCHAREA', 'TOTAL_TOAREA','STRUCTURE', 'GROUND_FLOOR', 'BASEMENT_FLOOR','MAINCDNM', 'OTHER_USE', 'GROUND_FLOOR', 'BASEMENT_FLOOR']
    for col in arr:
        # 구조코드명의 원-핫 인코딩
        scn_ohe = pd.get_dummies(df[col], prefix=col)
        # print(scn_ohe)
        # 원-핫 인코딩된 특성을 합치기
        df = pd.concat([df, scn_ohe], axis=1)
    df_dropped = df.drop(arr, axis=1)
    return df_dropped

# SQL 결과를 DataFrame으로 읽어오기
df = pd.read_sql(con=mydb.conn, sql=sql)
df1= create_matrix(df)

# print(df1)

# 'plat' 열을 제외한 나머지 열로 데이터프레임 생성
df_without_plat= df1.drop(['PLAT','USEYM'], axis=1)

# 코사인 유사도 계산
similarity_matrix = cosine_similarity(df_without_plat)

# 코사인 유사도 매트릭스 출력
# print(similarity_matrix)

import numpy as np
def search(nm):
    # 입력받은 건물 이름에 해당하는 주소의 인덱스 찾기
    matching_rows = df[df['PLAT'] == nm]

    # 행이 존재하는지 확인
    if not matching_rows.empty:
        # 해당 건물의 인덱스
        index = matching_rows.index[0]

        # 해당 주소의 유사도 벡터 추출
        similarity_vector = similarity_matrix[index]

        # 유사도에 따라 정렬하고 상위 6건의 인덱스 가져오기
        similar_indices = np.argsort(similarity_vector)[::-1][0:3]  # 자기 자신은 제외

        # 상위 6건의 주소 정보 가져오기
        similar_addresses = df1.iloc[similar_indices]

        # 원본 데이터에서 해당 건물들의 정보 가져오기
        original_building_info = df[df['PLAT'].isin(similar_addresses['PLAT'])]

        # 결과 출력
        print("입력한 건물 정보:")
        print(matching_rows)
        print("\n원본 데이터에서 해당 건물들의 정보:")
        print(original_building_info['PLAT'])
        return original_building_info['PLAT'].tolist()

        # original_building_info.to_csv('original_building_info.csv', index=False)
    else:
        print(f"건물명 '{nm}'에 해당하는 데이터가 없습니다.")

# 사용자 입력을 받아 검색 수행
while True:
    b_nm = input("건물명을 입력하세요 (종료하려면 'exit' 입력): ")
    if b_nm.lower() == 'exit':
        break
    similar_plats = search(b_nm)
    similar_plats_str = ', '.join([f"'{plat}'" for plat in similar_plats])
    sql1 = f"""SELECT *
        FROM (
            SELECT a.plat AS plat,
                   SUM(a.archarea) AS total_archarea,
                   SUM(a.toarea) AS total_toarea,
                   MIN(b.structure) AS structure,
                   MIN(a.maincdnm) AS maincdnm,
                   MIN(b.other_use) AS other_use,
                   ROUND(AVG(b.ground_floor), 0) AS ground_floor,
                   ROUND(AVG(b.basement_floor), 0) AS basement_floor,
                   a.useym AS useym,
                   AVG(a.useqty) AS useqty
            FROM main_gas_table a
            JOIN combined_gas b ON TRIM(a.plat) = TRIM(b.plat)
            WHERE a.useym BETWEEN 202301 AND 202307
                AND a.plat IN ({similar_plats_str})
            GROUP BY a.plat, a.useym
            HAVING COUNT(DISTINCT a.plat) > 0
            ORDER BY a.useym
        )"""
    df1 = pd.read_sql(con=mydb.conn, sql=sql1)
    df1_sorted = df1.sort_values(by=['PLAT', 'USEYM'], ascending=[True, True])
    print(df1_sorted)



