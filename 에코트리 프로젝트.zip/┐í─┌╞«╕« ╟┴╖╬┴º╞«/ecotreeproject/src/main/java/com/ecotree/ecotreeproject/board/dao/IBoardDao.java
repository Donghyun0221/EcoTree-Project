package com.ecotree.ecotreeproject.board.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ecotree.ecotreeproject.board.vo.BoardVO;

@Mapper
public interface IBoardDao {
	public List<BoardVO> getBoardList();
}
