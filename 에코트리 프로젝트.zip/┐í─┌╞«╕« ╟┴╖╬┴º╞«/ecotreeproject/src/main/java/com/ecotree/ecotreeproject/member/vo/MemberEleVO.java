package com.ecotree.ecotreeproject.member.vo;

public class MemberEleVO {
	private String useqty;
	private String useraddPlat;
	private String elecCharge;
			
	
	


	public MemberEleVO(String useqty, String useraddPlat, String elecCharge) {
		super();
		this.useqty = useqty;
		this.useraddPlat = useraddPlat;
		this.elecCharge = elecCharge;
	}





	@Override
	public String toString() {
		return "MemberEleVO [useqty=" + useqty + ", useraddPlat=" + useraddPlat + ", elecCharge=" + elecCharge + "]";
	}





	public String getUseqty() {
		return useqty;
	}





	public void setUseqty(String useqty) {
		this.useqty = useqty;
	}





	public String getUseraddPlat() {
		return useraddPlat;
	}





	public void setUseraddPlat(String useraddPlat) {
		this.useraddPlat = useraddPlat;
	}





	public String getElecCharge() {
		return elecCharge;
	}





	public void setElecCharge(String elecCharge) {
		this.elecCharge = elecCharge;
	}





	public MemberEleVO() {}
}
