package com.ecotree.ecotreeproject.member.vo;

public class MemberGasVO {
	private String useqty;
	private String useraddPlat;
	private String gasCharge;


public String getUseqty() {
		return useqty;
	}

	public void setUseqty(String useqty) {
		this.useqty = useqty;
	}


	public String getUseraddPlat() {
		return useraddPlat;
	}


	public void setUseraddPlat(String useraddPlat) {
		this.useraddPlat = useraddPlat;
	}

	public String getGasCharge() {
		return gasCharge;
	}

	public void setGasCharge(String gasCharge) {
		this.gasCharge = gasCharge;
	}


public MemberGasVO() {}
}

