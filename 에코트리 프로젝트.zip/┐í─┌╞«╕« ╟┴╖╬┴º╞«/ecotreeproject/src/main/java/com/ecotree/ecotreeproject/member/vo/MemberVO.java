package com.ecotree.ecotreeproject.member.vo;

public class MemberVO {
	private String userId;
	private String userPw;
	private String userNm;
	private String userEmail;
	private String useraddPlat;
	private String useraddnewPlat;
	private int veriFy;
	private String appYn;
	

    public MemberVO() {	
    }


	@Override
	public String toString() {
		return "MemberVO [userId=" + userId + ", userPw=" + userPw + ", userNm=" + userNm + ", userEmail=" + userEmail
				+ ", useraddPlat=" + useraddPlat + ", useraddnewPlat=" + useraddnewPlat + ", veriFy=" + veriFy
				+ ", appYn=" + appYn + "]";
	}


	public MemberVO(String userId, String userPw, String userNm, String userEmail, String useraddPlat,
			String useraddnewPlat, int veriFy, String appYn) {
		this.userId = userId;
		this.userPw = userPw;
		this.userNm = userNm;
		this.userEmail = userEmail;
		this.useraddPlat = useraddPlat;
		this.useraddnewPlat = useraddnewPlat;
		this.veriFy = veriFy;
		this.appYn = appYn;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getUserPw() {
		return userPw;
	}


	public void setUserPw(String userPw) {
		this.userPw = userPw;
	}


	public String getUserNm() {
		return userNm;
	}


	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}


	public String getUserEmail() {
		return userEmail;
	}


	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	public String getUseraddPlat() {
		return useraddPlat;
	}


	public void setUseraddPlat(String useraddPlat) {
		this.useraddPlat = useraddPlat;
	}


	public String getUseraddnewPlat() {
		return useraddnewPlat;
	}


	public void setUseraddnewPlat(String useraddnewPlat) {
		this.useraddnewPlat = useraddnewPlat;
	}


	public int getVeriFy() {
		return veriFy;
	}


	public void setVeriFy(int veriFy) {
		this.veriFy = veriFy;
	}


	public String getAppYn() {
		return appYn;
	}


	public void setAppYn(String appYn) {
		this.appYn = appYn;
	}
	

    


    

	
    
	

	
	

    

	
}
