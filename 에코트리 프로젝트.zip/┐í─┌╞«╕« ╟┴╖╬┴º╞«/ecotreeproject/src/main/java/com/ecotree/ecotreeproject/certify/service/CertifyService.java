package com.ecotree.ecotreeproject.certify.service;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecotree.ecotreeproject.certify.dao.ICertifyDAO;
import com.ecotree.ecotreeproject.certify.vo.CertifyVO;

@Service
public class CertifyService {
	
	@Autowired
	ICertifyDAO dao;
	
	public void certifyElec(CertifyVO certifyelec) throws Exception {
		int result = dao.certifyElec(certifyelec);
		System.out.println(result);
		if(result == 0) {
			throw new Exception();
		}
	}
	public List<CertifyVO> viewInfo(String userNm) {
	    // DAO의 viewInfo 메서드를 호출하여 데이터를 가져옴
	    List<CertifyVO> result = dao.viewInfo(userNm);

	    // 확인을 위해 데이터를 콘솔에 출력
	    for (CertifyVO certifyVO : result) {
	        System.out.println(certifyVO);
	    }

	    // 가져온 데이터를 반환
	    return result;
	}

	public List<CertifyVO>adminView() {
	List<CertifyVO> result = dao.adminView();
	return result;
	}
	public void updateYN(int iD) throws Exception {
		int result = dao.updateYN(iD);
		
		if(result ==0) {
			throw new Exception();
		}
	}
	public int elecInsert(CertifyVO elecinsert) {
	    try {
	        System.out.println("Elec Insert - " + elecinsert.toString());
	        return dao.elecInsert(elecinsert);
	    } catch (Exception e) {
	        e.printStackTrace();
	        throw new RuntimeException("Elec Insert failed: " + e.getMessage());
	    }
	}

	public int gasInsert(CertifyVO gasinsert) {
	    try {
	        System.out.println("Gas Insert - " + gasinsert.toString());
	        return dao.gasInsert(gasinsert);
	    } catch (Exception e) {
	        e.printStackTrace();
	        throw new RuntimeException("Gas Insert failed: " + e.getMessage());
	    }
	}
		
    
}
