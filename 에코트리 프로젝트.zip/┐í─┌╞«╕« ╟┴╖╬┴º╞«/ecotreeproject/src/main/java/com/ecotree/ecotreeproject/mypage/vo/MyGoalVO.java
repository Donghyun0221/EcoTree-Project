package com.ecotree.ecotreeproject.mypage.vo;

public class MyGoalVO {
	
	private String userId;
	private String userAddPlat;
	private String tv;
	private String cucu;
	private String wash;
	private String boiler;
	private String elecgoal;
	private String gasgoal;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserAddPlat() {
		return userAddPlat;
	}
	public void setUserAddPlat(String userAddPlat) {
		this.userAddPlat = userAddPlat;
	}
	public String getTv() {
		return tv;
	}
	public void setTv(String tv) {
		this.tv = tv;
	}
	public String getCucu() {
		return cucu;
	}
	public void setCucu(String cucu) {
		this.cucu = cucu;
	}
	public String getWash() {
		return wash;
	}
	public void setWash(String wash) {
		this.wash = wash;
	}
	public String getBoiler() {
		return boiler;
	}
	public void setBoiler(String boiler) {
		this.boiler = boiler;
	}
	public String getElecgoal() {
		return elecgoal;
	}
	public void setElecgoal(String elecgoal) {
		this.elecgoal = elecgoal;
	}
	public String getGasgoal() {
		return gasgoal;
	}
	public void setGasgoal(String gasgoal) {
		this.gasgoal = gasgoal;
	}
	@Override
	public String toString() {
		return "MyGoalVO [userId=" + userId + ", userAddPlat=" + userAddPlat + ", tv=" + tv + ", cucu=" + cucu
				+ ", wash=" + wash + ", boiler=" + boiler + ", elecgoal=" + elecgoal + ", gasgoal=" + gasgoal + "]";
	}
	
	
	
	
}
