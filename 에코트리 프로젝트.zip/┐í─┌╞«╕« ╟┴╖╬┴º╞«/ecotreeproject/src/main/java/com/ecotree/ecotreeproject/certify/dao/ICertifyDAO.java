package com.ecotree.ecotreeproject.certify.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.RowBounds;

import com.ecotree.ecotreeproject.certify.vo.CertifyVO;

@Mapper
public interface ICertifyDAO {
	public int certifyElec(CertifyVO certifyelec);
	public List<CertifyVO> viewInfo(String userNm);
	public List<CertifyVO> adminView();
	public int updateYN(int iD);
	public int elecInsert(CertifyVO elecinsert);
	public int gasInsert(CertifyVO gasinsert);
}
