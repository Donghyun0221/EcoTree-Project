package com.ecotree.ecotreeproject.member.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecotree.ecotreeproject.member.service.MemberService;
import com.ecotree.ecotreeproject.member.vo.MemberEleVO;
import com.ecotree.ecotreeproject.member.vo.MemberGasVO;
import com.ecotree.ecotreeproject.member.vo.MemberVO;

@Controller
public class MemberController {
	@Autowired 
	MemberService memberService; 
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@RequestMapping("/registecotreeView")
	public String registecotreeView() {
		return "member/registecotreeView";
	}
    @GetMapping("/identityView")
    public String identityView(HttpSession session, Model model) {
        MemberVO user = (MemberVO) session.getAttribute("login");
        String useraddPlat = user.getUseraddPlat();
        
        model.addAttribute("useraddPlat", useraddPlat);

        return "certify/identityView";
    }
    
    @ResponseBody
    @PostMapping("/getEleDo")
    public MemberEleVO getEleDo(HttpSession session) {
    	MemberVO user = (MemberVO) session.getAttribute("login");
    	String useraddPlat = user.getUseraddPlat();
    	System.out.println("확인해보기"+useraddPlat);
    	MemberEleVO result = memberService.ecotreeDate(useraddPlat);
    	System.out.println("확인해보기2"+result);    	
       return result;			
    }
    
    @ResponseBody
    @PostMapping("/getGasDo")
    public MemberGasVO getGasDo(HttpSession session) {
    	MemberVO user = (MemberVO) session.getAttribute("login");
    	String useraddPlat = user.getUseraddPlat();
    	System.out.println("확인해보기"+useraddPlat);
    	MemberGasVO result = memberService.ecotreeDate1(useraddPlat);
    	System.out.println("확인해보기2"+result);    	
       return result;			
    }
    
    
    
    
    

	@RequestMapping("/registDo")
	public String registDo(HttpServletRequest request) {
	    String id = request.getParameter("id");
	    String pw = passwordEncoder.encode(request.getParameter("pw"));
	    String nm = request.getParameter("nm");
	    String addr = request.getParameter("addr");
	    String plat = request.getParameter("plat");
	    String newplat = request.getParameter("newplat");
	    String appyn = request.getParameter("appyn");

	    // verify를 정수로 변환
	    int verify = 0; // 기본값 설정

	    String verifyParam = request.getParameter("verify");
	    if (verifyParam != null && !verifyParam.isEmpty()) {
	        try {
	            verify = Integer.parseInt(verifyParam);
	        } catch (NumberFormatException e) {
	            e.printStackTrace();
	            // verify를 정수로 변환하는 데 실패한 경우에 대한 예외 처리
	        }
	    }

	    MemberVO member = new MemberVO(id, pw, nm, addr, plat, newplat, verify, appyn);
	    try {
	        memberService.ecotreeMember(member);
	    } catch (Exception e) {
	        e.printStackTrace();
	        // 회원 등록 중 예외가 발생한 경우에 대한 예외 처리
	    }

	    return "redirect:/main";
	}
	@RequestMapping("/ecotreeloginView")
	public String ecotreeloginView(HttpServletRequest request, Model model) {
	String requestUrl = request.getHeader("Referer");
	model.addAttribute("fromUrl", requestUrl);
	return "member/ecotreeloginView";
    }
	@RequestMapping("/loginDo")
	public String loginDo(MemberVO member, HttpSession session
	            ,boolean remember, String fromUrl
	            ,HttpServletResponse response, Model model) {

	    MemberVO login = memberService.ecotreeLogin(member);	    
	    if (login == null) {
	        System.out.println("로그인 안됨");
	        model.addAttribute("error", "아이디 정보가 없습니다.");
	        return "redirect:/login"; // 로그인 페이지로 리다이렉트
	    }

	    // 로그인이 성공했을 때만 비밀번호 일치 여부 체크
	    boolean match = passwordEncoder.matches(member.getUserPw(), login.getUserPw());

	    if (!match) {
	        System.out.println("로그인 안됨");
	        model.addAttribute("error", "아이디 또는 비밀번호가 올바르지 않습니다.");
	        return "redirect:/login"; // 로그인 페이지로 리다이렉트

	    }

	    session.setAttribute("login", login);
	    		
	    if (remember) {
	        // true 쿠키 생성
	        Cookie cookie = new Cookie("rememberId", member.getUserId());
	        response.addCookie(cookie); // 응답하는 객체에 담아서 전달
	    } else {
	        // 쿠키 삭제
	        Cookie cookie = new Cookie("remeberId", "");
	        cookie.setMaxAge(0);
	        response.addCookie(cookie); // 응답하는 객체에 담아서 전달
	    }

	    return "redirect:/main";
	}

	@RequestMapping("/logoutDo")
	public String logoutDo(HttpSession session
				           ,HttpServletRequest request) {
		session.invalidate();
		String requestToURL = request.getRequestURI().toString();
		String requestUrl = request.getHeader("Referer");
		return "redirect:/main";
	}
	@ResponseBody
    @RequestMapping(value = "/updateAppYN", method = { RequestMethod.POST }, produces = "text/plain;charset=UTF-8")	
    public ResponseEntity<String> updateAppYN(
            @RequestParam("useraddPlat") String useraddPlat,
            @RequestParam("textWithoutSpaces") String textWithoutSpaces,
            HttpSession session) throws Exception {

        MemberVO user = (MemberVO) session.getAttribute("login");
        String loginUserNm = user.getUserNm();

        System.out.println("Received Data from Client:");
        System.out.println("useraddPlat from Client: " + useraddPlat);
        System.out.println("textWithoutSpaces from Client: " + textWithoutSpaces);
        System.out.println("usernm from Session: " + loginUserNm);
        
        Map<String, String> params = new HashMap<>();
        params.put("loginUserNm", ((MemberVO) session.getAttribute("login")).getUserNm());
        params.put("textWithoutSpaces", textWithoutSpaces);

        memberService.updateAppYN(params);
        // 업데이트 이후에 세션에서 로그인 정보 다시 가져오기
        MemberVO afteruser = (MemberVO) session.getAttribute("login");

        // 세션에 새로운 정보로 업데이트
        session.setAttribute("login", afteruser);

        // 강제로 app_yn을 Y로 변경
        afteruser.setAppYn("Y");

        // 업데이트 성공하면 메인 페이지로 이동
        System.out.println("바뀐로그인정보: " + afteruser.toString());
        
        
        return ResponseEntity.ok("업데이트 성공");
    }
    }