package com.ecotree.ecotreeproject.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecotree.ecotreeproject.main.dao.IMainDao;
import com.ecotree.ecotreeproject.main.vo.MainVO;

@Service
public class MainService {
	@Autowired
	IMainDao dao;

	public List<MainVO> getMainList() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<MainVO> carbon_all(){
		List<MainVO> result = dao.getCarbonAll();
		return result;
	}
	
	public List<MainVO> carbon_sgg(){
		List<MainVO> result = dao.getCarbonSgg();
		return result;
	}
	
	public List<MainVO> carbon_bjd(){
		List<MainVO> result = dao.getCarbonBjd();
		return result;
	}
	
	// 월별 지도
	public List<MainVO> energy_all(){
		List<MainVO> result = dao.getall_all();
		return result;
	}
	
	public List<MainVO> energy_sgg(int sigunguCd){
		List<MainVO> result = dao.getall_sgg(sigunguCd);
		return result;
	}
	
	public List<MainVO> energy_bjd(int bjdongCd){
		List<MainVO> result = dao.getall_bjd(bjdongCd);
		return result;
	}
	
	// 주소검색 기능
	public List<MainVO> get_add(){
		List<MainVO> result = dao.get_add();
		return result;
	}
	
	// 주소에 따른 차트 업데이트 기능
	public List<MainVO> get_add_data(String plat){
		List<MainVO> result = dao.get_add_data(plat);
		return result;
	}
	
	// 주소에 따른 차트 업데이트 기능 + 연도선택
	public List<MainVO> get_add_data_controll(String plat, String useYm){
		List<MainVO> result = dao.get_add_data_controll(plat, useYm);
		return result;
	}
	
	// 대전 전체 메인차트 연도선택
	public List<MainVO> change_data_all(String useYm){
		List<MainVO> result = dao.change_data_all(useYm);
		return result;
	}
	
	// 시군구별 메인차트 연도선택
	public List<MainVO> change_data_sgg(String useYm, int sigunguCd){
		List<MainVO> result = dao.change_data_sgg(useYm, sigunguCd);
		return result;
	}
	
	// 법정동별 메인차트 연도선택
	public List<MainVO> change_data_bjd(String useYm, int bjdongCd){
		List<MainVO> result = dao.change_data_bjd(useYm, bjdongCd);
		return result;
	}
	public List<MainVO>getcalculate(String sidoCode){
		List<MainVO> result = dao.getcalculateList(sidoCode);
		return result;
		
	}
	
	// 공공페이지 밑에 보여질 배출량/흡수량 지도
	// 최근데이터 흡수량 (시군구)
	public List<MainVO> get_emission_recent(){
		List<MainVO> result = dao.get_emission_recent();
		return result;
	}
	
	// 나무 + 녹지 더한 흡수량
	public List<MainVO> get_ab_all(){
		List<MainVO> result = dao.get_ab_all();
		return result;
	}
	
	// 대전 전체 기준 각각의 흡수량들 / 필요 나무 개수
	public List<MainVO> get_treeForest_all(){
		List<MainVO> result = dao.get_treeForest_all();
		return result;
	}
	
	public List<MainVO> get_rest_all(){
		List<MainVO> result = dao.get_rest_all();
		return result;
	}
	
	// 시군구별 흡수량과 필요나무
	public List<MainVO> get_treeForest_sgg(){
		List<MainVO> result = dao.get_treeForest_sgg();
		return result;
	}
	
	public List<MainVO> get_rest_sgg(){
		List<MainVO> result = dao.get_rest_sgg();
		return result;
	}
	
	///////// 예측값 데이터
	// 대전 전체
	public List<MainVO> get_pred_all(){
		List<MainVO> result = dao.get_pred_all();
		return result;
	}
	
	// 시군구별
	public List<MainVO> get_pred_sgg(int sigunguCd){
		List<MainVO> result = dao.get_pred_sgg(sigunguCd);
		return result;
	}
	
	// 주소별
	public List<MainVO> get_pred_add(String plat){
		List<MainVO> result = dao.get_pred_add(plat);
		return result;
	}


}
