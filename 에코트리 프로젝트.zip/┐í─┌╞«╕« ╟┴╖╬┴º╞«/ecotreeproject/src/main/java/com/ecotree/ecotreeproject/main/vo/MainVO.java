package com.ecotree.ecotreeproject.main.vo;

public class MainVO {
	

	private float totalCarnonEmssions;
	private long needTree;
	private String maincdNm;
	private String mainCd;
	private double elecUseQty;
	private double gasUseQty;
	private String useYm;
	private double carbonQty;
	private int sigunguCd;
	private int bjdongCd;
	private String codeNm;
	private int code;
	private String plat;
	private String newPlat;
	private double naturalSumAb;
	private double artfcSumAb;
    private double carbonEmssions;
    
    private long restCarbon;
    private long naturalAB;
    private long artfcAb;
    private long allsumAb;
    private long carbonAll;
    private String num2;
	public float getTotalCarnonEmssions() {
		return totalCarnonEmssions;
	}
	public void setTotalCarnonEmssions(float totalCarnonEmssions) {
		this.totalCarnonEmssions = totalCarnonEmssions;
	}
	public long getNeedTree() {
		return needTree;
	}
	public String getNum2() {
		return num2;
		
	}
	public void setNum2(String num2) {
		this.num2 = num2;
	}
	public void setNeedTree(long needTree) {
		this.needTree = needTree;
	}
	public String getMaincdNm() {
		return maincdNm;
	}
	public void setMaincdNm(String maincdNm) {
		this.maincdNm = maincdNm;
	}
	public String getMainCd() {
		return mainCd;
	}
	public void setMainCd(String mainCd) {
		this.mainCd = mainCd;
	}
	public double getElecUseQty() {
		return elecUseQty;
	}
	public void setElecUseQty(double elecUseQty) {
		this.elecUseQty = elecUseQty;
	}
	public double getGasUseQty() {
		return gasUseQty;
	}
	public void setGasUseQty(double gasUseQty) {
		this.gasUseQty = gasUseQty;
	}
	public String getUseYm() {
		return useYm;
	}
	public void setUseYm(String useYm) {
		this.useYm = useYm;
	}
	public double getCarbonQty() {
		return carbonQty;
	}
	public void setCarbonQty(double carbonQty) {
		this.carbonQty = carbonQty;
	}
	public int getSigunguCd() {
		return sigunguCd;
	}
	public void setSigunguCd(int sigunguCd) {
		this.sigunguCd = sigunguCd;
	}
	public int getBjdongCd() {
		return bjdongCd;
	}
	public void setBjdongCd(int bjdongCd) {
		this.bjdongCd = bjdongCd;
	}
	public String getCodeNm() {
		return codeNm;
	}
	public void setCodeNm(String codeNm) {
		this.codeNm = codeNm;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getPlat() {
		return plat;
	}
	public void setPlat(String plat) {
		this.plat = plat;
	}
	public String getNewPlat() {
		return newPlat;
	}
	public void setNewPlat(String newPlat) {
		this.newPlat = newPlat;
	}
	public double getNaturalSumAb() {
		return naturalSumAb;
	}
	public void setNaturalSumAb(double naturalSumAb) {
		this.naturalSumAb = naturalSumAb;
	}
	public double getArtfcSumAb() {
		return artfcSumAb;
	}
	public void setArtfcSumAb(double artfcSumAb) {
		this.artfcSumAb = artfcSumAb;
	}
	public double getCarbonEmssions() {
		return carbonEmssions;
	}
	public void setCarbonEmssions(double carbonEmssions) {
		this.carbonEmssions = carbonEmssions;
	}
	public long getRestCarbon() {
		return restCarbon;
	}
	public void setRestCarbon(long restCarbon) {
		this.restCarbon = restCarbon;
	}
	public long getNaturalAB() {
		return naturalAB;
	}
	public void setNaturalAB(long naturalAB) {
		this.naturalAB = naturalAB;
	}
	public long getArtfcAb() {
		return artfcAb;
	}
	public void setArtfcAb(long artfcAb) {
		this.artfcAb = artfcAb;
	}
	public long getAllsumAb() {
		return allsumAb;
	}
	public void setAllsumAb(long allsumAb) {
		this.allsumAb = allsumAb;
	}
	public long getCarbonAll() {
		return carbonAll;
	}
	public void setCarbonAll(long carbonAll) {
		this.carbonAll = carbonAll;
	}
	@Override
	public String toString() {
		return "MainVO [totalCarnonEmssions=" + totalCarnonEmssions + ", needTree=" + needTree + ", maincdNm="
				+ maincdNm + ", mainCd=" + mainCd + ", elecUseQty=" + elecUseQty + ", gasUseQty=" + gasUseQty
				+ ", useYm=" + useYm + ", carbonQty=" + carbonQty + ", sigunguCd=" + sigunguCd + ", bjdongCd="
				+ bjdongCd + ", codeNm=" + codeNm + ", code=" + code + ", plat=" + plat + ", newPlat=" + newPlat
				+ ", naturalSumAb=" + naturalSumAb + ", artfcSumAb=" + artfcSumAb + ", carbonEmssions=" + carbonEmssions
				+ ", restCarbon=" + restCarbon + ", naturalAB=" + naturalAB + ", artfcAb=" + artfcAb + ", allsumAb="
				+ allsumAb + ", carbonAll=" + carbonAll + ", num2=" + num2 + "]";
	}
    
	
    
	
    
    
    
    // 변수 크기 문제 때문에 (문제 생기면 이전 것(아래)으로 롤백)
//	public float getTotalCarnonEmssions() {
//		return totalCarnonEmssions;
//	}
//	public void setTotalCarnonEmssions(float totalCarnonEmssions) {
//		this.totalCarnonEmssions = totalCarnonEmssions;
//	}
//	public float getNeedTree() {
//		return needTree;
//	}
//	public void setNeedTree(float needTree) {
//		this.needTree = needTree;
//	}
//	public String getMaincdNm() {
//		return maincdNm;
//	}
//	public void setMaincdNm(String maincdNm) {
//		this.maincdNm = maincdNm;
//	}
//	public String getMainCd() {
//		return mainCd;
//	}
//	public void setMainCd(String mainCd) {
//		this.mainCd = mainCd;
//	}
//	public double getElecUseQty() {
//		return elecUseQty;
//	}
//	public void setElecUseQty(double elecUseQty) {
//		this.elecUseQty = elecUseQty;
//	}
//	public double getGasUseQty() {
//		return gasUseQty;
//	}
//	public void setGasUseQty(double gasUseQty) {
//		this.gasUseQty = gasUseQty;
//	}
//	public String getUseYm() {
//		return useYm;
//	}
//	public void setUseYm(String useYm) {
//		this.useYm = useYm;
//	}
//	public double getCarbonQty() {
//		return carbonQty;
//	}
//	public void setCarbonQty(double carbonQty) {
//		this.carbonQty = carbonQty;
//	}
//	public int getSigunguCd() {
//		return sigunguCd;
//	}
//	public void setSigunguCd(int sigunguCd) {
//		this.sigunguCd = sigunguCd;
//	}
//	public int getBjdongCd() {
//		return bjdongCd;
//	}
//	public void setBjdongCd(int bjdongCd) {
//		this.bjdongCd = bjdongCd;
//	}
//	public String getCodeNm() {
//		return codeNm;
//	}
//	public void setCodeNm(String codeNm) {
//		this.codeNm = codeNm;
//	}
//	public int getCode() {
//		return code;
//	}
//	public void setCode(int code) {
//		this.code = code;
//	}
//	public String getPlat() {
//		return plat;
//	}
//	public void setPlat(String plat) {
//		this.plat = plat;
//	}
//	public String getNewPlat() {
//		return newPlat;
//	}
//	public void setNewPlat(String newPlat) {
//		this.newPlat = newPlat;
//	}
//	public double getNaturalSumAb() {
//		return naturalSumAb;
//	}
//	public void setNaturalSumAb(double naturalSumAb) {
//		this.naturalSumAb = naturalSumAb;
//	}
//	public double getArtfcSumAb() {
//		return artfcSumAb;
//	}
//	public void setArtfcSumAb(double artfcSumAb) {
//		this.artfcSumAb = artfcSumAb;
//	}
//	public double getCarbonEmssions() {
//		return carbonEmssions;
//	}
//	public void setCarbonEmssions(double carbonEmssions) {
//		this.carbonEmssions = carbonEmssions;
//	}
//	@Override
//	public String toString() {
//		return "MainVO [totalCarnonEmssions=" + totalCarnonEmssions + ", needTree=" + needTree + ", maincdNm="
//				+ maincdNm + ", mainCd=" + mainCd + ", elecUseQty=" + elecUseQty + ", gasUseQty=" + gasUseQty
//				+ ", useYm=" + useYm + ", carbonQty=" + carbonQty + ", sigunguCd=" + sigunguCd + ", bjdongCd="
//				+ bjdongCd + ", codeNm=" + codeNm + ", code=" + code + ", plat=" + plat + ", newPlat=" + newPlat
//				+ ", naturalSumAb=" + naturalSumAb + ", artfcSumAb=" + artfcSumAb + ", carbonEmssions=" + carbonEmssions
//				+ "]";
//	}

	
	

	
}
