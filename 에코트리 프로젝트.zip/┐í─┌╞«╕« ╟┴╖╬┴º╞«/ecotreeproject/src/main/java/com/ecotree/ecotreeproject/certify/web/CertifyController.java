package com.ecotree.ecotreeproject.certify.web;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecotree.ecotreeproject.certify.service.CertifyService;
import com.ecotree.ecotreeproject.certify.vo.CertifyVO;
import com.ecotree.ecotreeproject.member.vo.MemberVO;

@Controller
public class CertifyController {
	@Autowired
	CertifyService certifyService;

	@RequestMapping("/admincertifyView")
	public String admincertifyView(Model model, HttpSession session) {
		MemberVO user = (MemberVO) session.getAttribute("login");
		if (user == null) {
			return "redirect:/ecotreeloginView";
		}

		String userNm = user.getUserNm(); // MemberVO에서 userNm 추출
		List<CertifyVO> viewList = certifyService.viewInfo(userNm);

		System.out.println("Returned data size: " + viewList.size());
		for (CertifyVO certifyVO : viewList) {
			System.out.println(certifyVO);
		}

		model.addAttribute("viewList", viewList);
		return "certify/admincertifyView";
	}

	@RequestMapping("/certifyView")
	public String certifyelecView(HttpSession session) {

		if (session.getAttribute("login") == null) {
			return "redirect:/ecotreeloginView";
		}
		return "certify/certifyView";
	}

	@RequestMapping("/certifyDo")
	public String certifyDo(HttpServletRequest request, CertifyVO vo, Model model, HttpSession session) {
		MemberVO user = (MemberVO) session.getAttribute("login");
		System.out.println(vo);
		System.out.println(user);
		if (user == null || !user.getUserNm().equals(vo.getUserNm())) {
			System.out.println("같지않음");
			return "redirect:/login";
		}

		try {
			certifyService.certifyElec(vo);
			// CertifyelecVO 객체를 모델 속성으로 추가
			model.addAttribute("certifyelecVO", vo);
			// forward로 admincertifyView 페이지로 전환
			return "forward:/admincertifyView";
		} catch (Exception e) {
			e.printStackTrace();
			return "redirect:/login"; // 예외 발생 시 로그인 페이지로 리다이렉트
		}
	}

	@RequestMapping("/adminPage")
	public String adminPage(Model model, HttpSession session) {
		List<CertifyVO> adminList = certifyService.adminView();
		model.addAttribute("adminList", adminList);
		return "admin/adminPage";
	}
	
	@ResponseBody
	@RequestMapping(value = "/adminDo", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public ResponseEntity<String> adminDo(@RequestBody CertifyVO certifyVO) {
	    try {
	        // CertifyService를 사용하여 updateYN 메서드 호출
	        certifyService.updateYN(certifyVO.getiD());

	        // CertifyService를 사용하여 elecInsert, gasInsert 메서드 호출
	        certifyService.elecInsert(certifyVO);
	        certifyService.gasInsert(certifyVO);

	        // 성공 메시지 반환
	        return ResponseEntity.ok("승인이 성공적으로 처리되었습니다.");
	    } catch (Exception e) {
	        // 실패 시 예외 메시지 반환
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("{'error': '" + e.getMessage() + "'}");
	    }
	}
}
