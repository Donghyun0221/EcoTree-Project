package com.ecotree.ecotreeproject.main.web;

import java.util.List;
import java.util.Locale;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecotree.ecotreeproject.main.service.MainService;
import com.ecotree.ecotreeproject.main.vo.MainVO;
import com.ecotree.ecotreeproject.member.vo.MemberVO;

/**
 * Class Name : MainController Author : SaWeonGi Created Date: 2023. 11. 27.
 * Version: 1.0 Purpose: Description:
 */
@Controller
public class MainController {
	/**
	 * 
	 */
	@Inject
	MainService service;
	
	@RequestMapping("/model_chart")
	public String model_chart() {
		return "main/model_chart";
	}
	
	
	@RequestMapping("/main_personal")
	public String test2_personal() {
		return "main/main_personal";
	}
	
	//차트 확인용 페이지 컨트롤러 (완료되면 지우기)
	@RequestMapping("/datamap")
	public String datamap_test(Model model) {
		List<MainVO> get_ablist_all = service.get_treeForest_all();
		model.addAttribute("get_ablist_all", get_ablist_all);
		
		List<MainVO> get_rest_all = service.get_rest_all();
		model.addAttribute("get_rest_all", get_rest_all);
		
		return "main/datamap";
	}
	@RequestMapping("/datamap_test")
	public String datamap_test1() {
		return "main/datamap_test";
	}
	//(확인용 끝)
	
	@RequestMapping("/error")
	public String error() {
		return "main/error";
	}
	
	@RequestMapping("/nokji")
	public String nokji() {
		return "main/nokji";
	}
	
	// 차트 기능 컨트롤러
	@RequestMapping(value = "/getcarbonall", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public  List<MainVO> getcarbonall (Model model){
		List<MainVO> carbon_all = service.carbon_all();
		model.addAttribute("carbon_all", carbon_all);
		return carbon_all;
	}
	
	@RequestMapping(value = "/getcarbonsgg", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public  List<MainVO> getcarbonsgg (Model model){
		List<MainVO> carbon_sgg = service.carbon_sgg();
		model.addAttribute("carbon_sgg", carbon_sgg);
		return carbon_sgg;
	}
	
	@RequestMapping(value = "/getcarbonbjd", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public  List<MainVO> getcarbonbjd (Model model){
		List<MainVO> carbon_bjd = service.carbon_bjd();
		model.addAttribute("elec_bjd", carbon_bjd);
		return carbon_bjd;
	}
	
	// 축 3개 메인차트
	@RequestMapping(value = "/getenergy_all", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public  List<MainVO> getenergy_all (Model model){
		List<MainVO> energy_all = service.energy_all();
		model.addAttribute("energy_all", energy_all);
		return energy_all;
	}
	
	@RequestMapping(value = "/getenergy_sgg", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public  List<MainVO> getenergy_sgg (Model model, int sigunguCd){
		List<MainVO> energy_sgg = service.energy_sgg(sigunguCd);
		model.addAttribute("energy_sgg", energy_sgg);
		return energy_sgg;
	}
	
	@RequestMapping(value = "/getenergy_bjd", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public  List<MainVO> getenergy_bjd (Model model, int bjdongCd){
		List<MainVO> energy_bjd = service.energy_bjd(bjdongCd);
		model.addAttribute("energy_bjd", energy_bjd);
		return energy_bjd;
	}
	
	// * 차트 기능 끝
	
	
	// 주소검색 기능
	@RequestMapping(value = "/get_add", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_add (Model model){
		List<MainVO> get_add = service.get_add();
		model.addAttribute("get_add", get_add);
		return get_add;
	}
	
	// 주소에 따른 차트 업데이트
	@RequestMapping(value = "/get_add_data", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_add_data(String plat, Model model){
		List<MainVO> get_add_data = service.get_add_data(plat);
		model.addAttribute("get_add_data", get_add_data);
		return get_add_data;
	}
	
	@RequestMapping(value = "/get_add_data_controll", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_add_data_controll(String plat, String useYm, Model model){
		List<MainVO> get_add_data_controll = service.get_add_data_controll(plat, useYm);
		model.addAttribute("get_add_data_controll", get_add_data_controll);
		return get_add_data_controll;
	}
	
	// 연도 선택에 따른 차트 업데이트
	// 1. 대전 전체 연도 선택
	@RequestMapping(value = "/change_data_all", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> change_data_all(String useYm, Model model){
		List<MainVO> chage_data_all = service.change_data_all(useYm);
		model.addAttribute("change_data_all", chage_data_all);
		return chage_data_all;
	}
	
	// 2. 시군구별 연도 선택
	@RequestMapping(value = "/change_data_sgg", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> change_data_sgg(String useYm, int sigunguCd, Model model){
		List<MainVO> change_data_sgg = service.change_data_sgg(useYm, sigunguCd);
		model.addAttribute("change_data_sgg", change_data_sgg);
		return change_data_sgg;
	}
	
	// 3. 법정동별 연도 선택
	@RequestMapping(value = "/change_data_bjd", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> change_data_bjd(String useYm, int bjdongCd, Model model){
		List<MainVO> change_data_bjd = service.change_data_bjd(useYm, bjdongCd);
		model.addAttribute("change_data_bjd", change_data_bjd);
		return change_data_bjd;
	}
	
	// 공공페이지 밑에 보여질 흡수량/배출량 지도
	// 최근배출량
	@RequestMapping(value = "/get_emission_recent", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_emission_recent(Model model){
		List<MainVO> get_emission_recent = service.get_emission_recent();
		model.addAttribute("get_emission_recent", get_emission_recent);
		return get_emission_recent;
	}
	
	// 나무+녹지 흡수량 (대전전체)
	@RequestMapping(value = "/get_ab_all", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_ab_all(Model model){
		List<MainVO> get_ab_all = service.get_ab_all();
		model.addAttribute("get_ab_all", get_ab_all);
		return get_ab_all;
	}
	
	// 나무 녹지 흡수량 (시군구별)
	@RequestMapping(value = "/get_treeForest_sgg", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_treeForest_sgg(Model model){
		List<MainVO> get_treeForest_sgg = service.get_treeForest_sgg();
		model.addAttribute("get_treeForest_sgg", get_treeForest_sgg);
		return get_treeForest_sgg;
	}
	// 잔여 흡수량과 필요나무 (시군구별)
	@RequestMapping(value = "/get_rest_sgg", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_rest_sgg(Model model){
		List<MainVO> get_rest_sgg = service.get_rest_sgg();
		model.addAttribute("get_rest_sgg", get_rest_sgg);
		return get_rest_sgg;
	}
	
	///// 예측값 받아오는 컨트롤러
	// 대전 전체
	@RequestMapping(value = "/get_pred_all", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_pred_all(Model model){
		List<MainVO> get_pred_all = service.get_pred_all();
		model.addAttribute("get_pred_all", get_pred_all);
		return get_pred_all;
	}
	
	// 시군구별
	@RequestMapping(value = "/get_pred_sgg", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_pred_sgg(Model model, int sigunguCd){
		List<MainVO> get_pred_sgg = service.get_pred_sgg(sigunguCd);
		model.addAttribute("get_pred_sgg", get_pred_sgg);
		return get_pred_sgg;
	}
	
	// 주소별
	@RequestMapping(value = "/get_pred_add", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public List<MainVO> get_pred_add(Model model, String plat){
		List<MainVO> get_pred_add = service.get_pred_add(plat);
		model.addAttribute("get_pred_add", get_pred_add);
		return get_pred_add;
	}
	
	
	
	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String board(Locale locale, Model model) {
		List<MainVO> mainList = service.getMainList();
		model.addAttribute("MainList", mainList);

		List<MainVO> getcalculate = service.getcalculate("30110");
		model.addAttribute("getcalculate", getcalculate);
		
		// 하단 녹지 지도
		List<MainVO> get_ablist_all = service.get_treeForest_all();
		model.addAttribute("get_ablist_all", get_ablist_all);
		
		List<MainVO> get_rest_all = service.get_rest_all();
		model.addAttribute("get_rest_all", get_rest_all);

		return "main/main";
		
	}
	

	/*
	 * @RequestMapping(value="/main") public String calculate(Model model) {
	 * List<MainVO>getcalculate = service.getcalculate();
	 * model.addAttribute("getcalculate", getcalculate); return "main/main";
	 * 
	 * 
	 * 
	 * }
	 */
	@ResponseBody
	@PostMapping("/getcalculateList.do")
    public List<MainVO> getcalculateList(@RequestParam String sidoCode, HttpSession session) throws Exception {
		System.out.println(sidoCode);
		MemberVO user = (MemberVO) session.getAttribute("login");
        String useraddPlat = user.getUseraddPlat();
        String userid = user.getUserId();
		List<MainVO> getcalculate = service.getcalculate(sidoCode);
		System.out.println(getcalculate);
		return getcalculate;
	}

	 @PostMapping("/saveNum2ToDatabase")
	    @ResponseBody
	    public String saveNum2ToDatabase(@RequestParam("num2") String num2) {
	        // 여기에 데이터베이스에 num2를 저장하는 로직을 추가하세요
	        // 예를 들어, DatabaseService.saveNum2(num2);
		 

	        return "num2 데이터 saved successfully!";
	    }

}
