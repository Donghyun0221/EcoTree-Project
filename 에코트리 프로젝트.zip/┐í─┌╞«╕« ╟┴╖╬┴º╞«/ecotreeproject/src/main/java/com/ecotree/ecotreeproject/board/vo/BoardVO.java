package com.ecotree.ecotreeproject.board.vo;

public class BoardVO {
	private String plat;
	private String newPlat;
	private int sigunguCd;
	public BoardVO(String plat, String newPlat, int sigunguCd) {
		this.plat = plat;
		this.newPlat = newPlat;
		this.sigunguCd = sigunguCd;
	}
	@Override
	public String toString() {
		return "BoardVO [plat=" + plat + ", newPlat=" + newPlat + ", sigunguCd=" + sigunguCd + "]";
	}
	public String getPlat() {
		return plat;
	}
	public void setPlat(String plat) {
		this.plat = plat;
	}
	public String getNewPlat() {
		return newPlat;
	}
	public void setNewPlat(String newPlat) {
		this.newPlat = newPlat;
	}
	public int getSigunguCd() {
		return sigunguCd;
	}
	public void setSigunguCd(int sigunguCd) {
		this.sigunguCd = sigunguCd;
	}
	
	
	
}
