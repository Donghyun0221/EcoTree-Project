package com.ecotree.ecotreeproject.board.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.ecotree.ecotreeproject.board.dao.IBoardDao;
import com.ecotree.ecotreeproject.board.vo.BoardVO;

@Service
public class BoardService {
	
	@Inject
	IBoardDao boardDao;
	
	/**
	 * @Author : SaWeonGi
	 * @Date   : 2023. 11. 22.
	 * @Method : getBoardList
	 * @return : List<BoardVO>
	 * Purpose :
	 * Description : 
	*/
	public List<BoardVO> getBoardList(){
		return boardDao.getBoardList();
	}
}

