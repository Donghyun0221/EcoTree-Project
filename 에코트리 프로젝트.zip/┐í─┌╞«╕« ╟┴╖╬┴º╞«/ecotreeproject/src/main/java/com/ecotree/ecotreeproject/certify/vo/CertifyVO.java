package com.ecotree.ecotreeproject.certify.vo;

public class CertifyVO {
	private int iD;
	private String userNm;
	private String useraddPlat;
	private String useraddnewPlat;
	private String useYm;
	private int elecuseQty; //elec_useqty
	private int gasuseQty;
	private int elecCharge; //elec_charge
	private int gasCharge;
	private String submitDay;
	private String appYn;
	
    public CertifyVO() {	
    }

	@Override
	public String toString() {
		return "CertifyVO [iD=" + iD + ", userNm=" + userNm + ", useraddPlat=" + useraddPlat + ", useraddnewPlat="
				+ useraddnewPlat + ", useYm=" + useYm + ", elecuseQty=" + elecuseQty + ", gasuseQty=" + gasuseQty
				+ ", elecCharge=" + elecCharge + ", gasCharge=" + gasCharge + ", submitDay=" + submitDay + ", appYn="
				+ appYn + "]";
	}

	public CertifyVO(int iD, String userNm, String useraddPlat, String useraddnewPlat, String useYm, int elecuseQty,
			int gasuseQty, int elecCharge, int gasCharge, String submitDay, String appYn) {
		this.iD = iD;
		this.userNm = userNm;
		this.useraddPlat = useraddPlat;
		this.useraddnewPlat = useraddnewPlat;
		this.useYm = useYm;
		this.elecuseQty = elecuseQty;
		this.gasuseQty = gasuseQty;
		this.elecCharge = elecCharge;
		this.gasCharge = gasCharge;
		this.submitDay = submitDay;
		this.appYn = appYn;
	}

	public int getiD() {
		return iD;
	}

	public void setiD(int iD) {
		this.iD = iD;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getUseraddPlat() {
		return useraddPlat;
	}

	public void setUseraddPlat(String useraddPlat) {
		this.useraddPlat = useraddPlat;
	}

	public String getUseraddnewPlat() {
		return useraddnewPlat;
	}

	public void setUseraddnewPlat(String useraddnewPlat) {
		this.useraddnewPlat = useraddnewPlat;
	}

	public String getUseYm() {
		return useYm;
	}

	public void setUseYm(String useYm) {
		this.useYm = useYm;
	}

	public int getElecuseQty() {
		return elecuseQty;
	}

	public void setElecuseQty(int elecuseQty) {
		this.elecuseQty = elecuseQty;
	}

	public int getGasuseQty() {
		return gasuseQty;
	}

	public void setGasuseQty(int gasuseQty) {
		this.gasuseQty = gasuseQty;
	}

	public int getElecCharge() {
		return elecCharge;
	}

	public void setElecCharge(int elecCharge) {
		this.elecCharge = elecCharge;
	}

	public int getGasCharge() {
		return gasCharge;
	}

	public void setGasCharge(int gasCharge) {
		this.gasCharge = gasCharge;
	}

	public String getSubmitDay() {
		return submitDay;
	}

	public void setSubmitDay(String submitDay) {
		this.submitDay = submitDay;
	}

	public String getAppYn() {
		return appYn;
	}

	public void setAppYn(String appYn) {
		this.appYn = appYn;
	}
	

	
    



    
	
}
