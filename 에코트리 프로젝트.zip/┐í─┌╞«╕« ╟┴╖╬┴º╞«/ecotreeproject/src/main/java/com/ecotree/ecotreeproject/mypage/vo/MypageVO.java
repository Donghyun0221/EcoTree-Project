package com.ecotree.ecotreeproject.mypage.vo;

public class MypageVO {
	private String plat;
	private String maincdNm;
	private String useYm;
	private int elecCharge;
	private int gasCharge;
	
	@Override
	public String toString() {
		return "MypageVO [plat=" + plat + ", maincdNm=" + maincdNm + ", useYm=" + useYm + ", elecCharge=" + elecCharge
				+ ", gasCharge=" + gasCharge + "]";
	}

	public MypageVO(String plat, String maincdNm, String useYm, int elecCharge, int gasCharge) {
		this.plat = plat;
		this.maincdNm = maincdNm;
		this.useYm = useYm;
		this.elecCharge = elecCharge;
		this.gasCharge = gasCharge;
	}

	public String getPlat() {
		return plat;
	}

	public void setPlat(String plat) {
		this.plat = plat;
	}

	public String getMaincdNm() {
		return maincdNm;
	}

	public void setMaincdNm(String maincdNm) {
		this.maincdNm = maincdNm;
	}

	public String getUseYm() {
		return useYm;
	}

	public void setUseYm(String useYm) {
		this.useYm = useYm;
	}

	public int getElecCharge() {
		return elecCharge;
	}

	public void setElecCharge(int elecCharge) {
		this.elecCharge = elecCharge;
	}

	public int getGasCharge() {
		return gasCharge;
	}

	public void setGasCharge(int gasCharge) {
		this.gasCharge = gasCharge;
	}

    
    public MypageVO() {	
    	
    }

	
}
