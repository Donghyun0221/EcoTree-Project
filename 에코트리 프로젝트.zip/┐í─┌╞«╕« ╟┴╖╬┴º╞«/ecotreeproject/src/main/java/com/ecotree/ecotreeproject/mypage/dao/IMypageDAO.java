package com.ecotree.ecotreeproject.mypage.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ecotree.ecotreeproject.mypage.vo.MyGoalVO;
import com.ecotree.ecotreeproject.mypage.vo.MypageVO;

@Mapper
public interface IMypageDAO {
	public List<MypageVO> mypageView(String useraddPlat);
	public int myGoalInsert(MyGoalVO vo);
	public MyGoalVO myGoalView(String useraddPlat);
}
