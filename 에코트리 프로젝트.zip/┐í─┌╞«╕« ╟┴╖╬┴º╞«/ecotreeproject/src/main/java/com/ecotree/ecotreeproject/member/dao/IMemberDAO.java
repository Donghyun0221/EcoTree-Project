package com.ecotree.ecotreeproject.member.dao;

import java.util.List;
import java.util.Map;


import com.ecotree.ecotreeproject.member.vo.MemberEleVO;
import com.ecotree.ecotreeproject.member.vo.MemberGasVO;
import com.ecotree.ecotreeproject.member.vo.MemberVO;

public interface IMemberDAO {
	public int ecotreeMember(MemberVO member);
	public MemberVO ecotreeLogin(MemberVO member);
	public int updateAppYN(Map<String, String> params);
	public MemberEleVO ecotreeDate(String useraddPlat);
	public MemberGasVO ecotreeDate1(String useraddPlat);
	
}
