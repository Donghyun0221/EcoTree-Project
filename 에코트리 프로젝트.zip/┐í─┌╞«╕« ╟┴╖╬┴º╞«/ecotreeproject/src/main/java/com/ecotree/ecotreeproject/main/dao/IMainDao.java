package com.ecotree.ecotreeproject.main.dao;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.ecotree.ecotreeproject.main.vo.MainVO;


@Mapper
public interface IMainDao {
	
	// 용도별 탄소배출량 지도
	public List<MainVO> getCarbonAll();
	public List<MainVO> getCarbonSgg();
	public List<MainVO> getCarbonBjd();
	
	// 주소별 메인지도
	public List<MainVO> getall_all();
	public List<MainVO> getall_sgg(int sigunguCd);
	public List<MainVO> getall_bjd(int bjdongCd);
	public List<MainVO> get_add();
	
	// 주소별 메인차트 (기본 최근 12개월)
	public List<MainVO> get_add_data(String plat);
	
	// 주소별 메인차트 (월별선택)
	public List<MainVO> get_add_data_controll(@Param("plat")String plat, @Param("useYm")String useYm);
	
	// 대전 전체 월별선택 메인차트
	public List<MainVO> change_data_all(String useYm);
	
	// 시군구 월별선택 메인차트
	public List<MainVO> change_data_sgg(@Param("useYm")String useYm, @Param("sigunguCd")int sigunguCd);
	
	// 법정동별 월별선택 메인차트
	public List<MainVO> change_data_bjd(@Param("useYm")String useYm, @Param("bjdongCd")int bjdongCd);

	public List<MainVO> getcalculateList(String sidoCode);
	
	// 공공페이지 밑에 보여질 배출량/흡수량 지도
	// 최근배출량
	public List<MainVO> get_emission_recent();
	public List<MainVO> get_ab_all();
	
	// 대전 전체 기준 흡수량
	public List<MainVO> get_treeForest_all();
	public List<MainVO> get_rest_all();
	
	// 시군구별 흡수량
	public List<MainVO> get_rest_sgg();
	public List<MainVO> get_treeForest_sgg();
	public String num2(MainVO num2);
	

	
	// 예측값 차트에 넣기
	// 대전 전체
	public List<MainVO> get_pred_all();
	
	// 시군구
	public List<MainVO> get_pred_sgg(int sigunguCd);
	
	// 주소별
	public List<MainVO> get_pred_add(String plat);


}
