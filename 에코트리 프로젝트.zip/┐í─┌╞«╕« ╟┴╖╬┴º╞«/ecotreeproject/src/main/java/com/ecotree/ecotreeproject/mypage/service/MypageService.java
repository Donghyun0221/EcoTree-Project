package com.ecotree.ecotreeproject.mypage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecotree.ecotreeproject.certify.vo.CertifyVO;
import com.ecotree.ecotreeproject.mypage.dao.IMypageDAO;
import com.ecotree.ecotreeproject.mypage.vo.MyGoalVO;
import com.ecotree.ecotreeproject.mypage.vo.MypageVO;

@Service
public class MypageService {
	
	@Autowired
	IMypageDAO dao;
	
	public List<MypageVO> mypageView(String useraddPlat) {
	    // DAO의 viewInfo 메서드를 호출하여 데이터를 가져옴
	    List<MypageVO> result = dao.mypageView(useraddPlat);

	    // 확인을 위해 데이터를 콘솔에 출력
	    for (MypageVO mypageVO : result) {
	        System.out.println(mypageVO);
	    }

	    // 가져온 데이터를 반환
	    return result;
	}
	 public int myGoalInsert(MyGoalVO vo) throws Exception {
		      int result = dao.myGoalInsert(vo);
		      System.out.println(result);
		      return result;
		   }
	 
	 public MyGoalVO myGoalView(String useraddPlat) {
		 
		 MyGoalVO result = dao.myGoalView(useraddPlat);
		 System.out.println(result);
		return result;
	 }
    
}
