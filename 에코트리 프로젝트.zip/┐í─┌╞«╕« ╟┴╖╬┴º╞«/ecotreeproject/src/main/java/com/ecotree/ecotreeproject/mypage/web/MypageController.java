package com.ecotree.ecotreeproject.mypage.web;

import java.lang.System.Logger;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.mybatis.logging.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecotree.ecotreeproject.member.vo.MemberVO;
import com.ecotree.ecotreeproject.mypage.service.MypageService;
import com.ecotree.ecotreeproject.mypage.vo.MyGoalVO;
import com.ecotree.ecotreeproject.mypage.vo.MypageVO;

@Controller
public class MypageController {
	
	@Inject
	MypageService service;
	
	@RequestMapping("/mypageView_Test")
	public String mypageView(HttpSession session, Model model) {
    	MemberVO user = (MemberVO) session.getAttribute("login");
    	String useraddPlat = user.getUseraddPlat();
    	System.out.println("로그인 대지위치"+useraddPlat);
    	List<MypageVO> myPage  = service.mypageView(useraddPlat);
    	System.out.println("가져온 내용"+ myPage);
    	MyGoalVO mygoal = service.myGoalView(useraddPlat);
    	System.out.println("잘 보내진건가?"+ mygoal);
		
        // 모델에 데이터 추가
        model.addAttribute("myPageData", myPage);
        model.addAttribute("myGoalData", mygoal);
    	
		return "member/mypageView_Test";
	}
	

	@ResponseBody
	   @PostMapping("/myGoalRegist.do")
	    public String myGoalRegist(MyGoalVO vo,HttpSession session) throws Exception {
	      MemberVO login = (MemberVO) session.getAttribute("login");
	      vo.setUserId(login.getUserId());
	      vo.setUserAddPlat(login.getUseraddPlat());
	      System.out.println(vo);
	      int cnt = service.myGoalInsert(vo);
	      if(cnt == 0) {
	         return "f";
	      }else {
	         return "s";
	      }
	   }
	@GetMapping("/error404")
	public String error404(Model model) {
	    model.addAttribute("code", "ERROR_404");
	    return "main/error";
	}

	@GetMapping("/error500")
	public String error500(Model model) {
	    model.addAttribute("code", "ERROR_500");
	    return "main/error";
	}

}
