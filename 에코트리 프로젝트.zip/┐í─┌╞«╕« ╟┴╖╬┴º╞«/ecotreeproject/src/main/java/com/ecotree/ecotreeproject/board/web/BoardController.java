package com.ecotree.ecotreeproject.board.web;

import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ecotree.ecotreeproject.board.service.BoardService;
import com.ecotree.ecotreeproject.board.vo.BoardVO;

/**
 * Class Name  : BoardController
 * Author      : SaWeonGi
 * Created Date: 2023. 11. 22.
 * Version: 1.0
 * Purpose:   
 * Description: 
 */
@Controller
public class BoardController {

 @Inject
 BoardService service;
 
 @RequestMapping(value ="/board",  method = RequestMethod.GET)
 public String board(Locale locale, Model model) {
	 List<BoardVO> boardList = service.getBoardList();
	 model.addAttribute("boardList",boardList);
	 return "board/board";
 }

}
