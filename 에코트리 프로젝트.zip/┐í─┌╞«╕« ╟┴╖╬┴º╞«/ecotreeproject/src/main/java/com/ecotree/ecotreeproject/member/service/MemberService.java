package com.ecotree.ecotreeproject.member.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecotree.ecotreeproject.member.dao.IMemberDAO;
import com.ecotree.ecotreeproject.member.vo.MemberEleVO;
import com.ecotree.ecotreeproject.member.vo.MemberGasVO;
import com.ecotree.ecotreeproject.member.vo.MemberVO;

@Service
public class MemberService {
	
	@Autowired
	IMemberDAO dao;
	
	public void ecotreeMember(MemberVO member) throws Exception {
		int result = dao.ecotreeMember(member);
//		System.out.println(result);
		if(result == 0) {
			throw new Exception();
		}
	}
	public MemberVO ecotreeLogin(MemberVO member) {
		MemberVO result = dao.ecotreeLogin(member);
		System.out.println(result);
		if(result == null) {
			return null;
		}
		return result;
	}

    public void updateAppYN(Map<String, String> params) throws Exception {
        System.out.println("Updating app_yn. User: " + params.get("loginUserNm") + ", TextWithoutSpaces: " + params.get("textWithoutSpaces"));
        int result = dao.updateAppYN(params);
        if(result == 0) {
        	throw new Exception();
        }
    }
    
    public MemberEleVO ecotreeDate(String useraddPlat) {
    	MemberEleVO result = dao.ecotreeDate(useraddPlat);
    	if(result == null) {
			return null;
		}
		return result;
    	
    }
    public MemberGasVO ecotreeDate1(String useraddPlat) {
    	MemberGasVO result = dao.ecotreeDate1(useraddPlat);
    	if(result == null) {
			return null;
		}
		return result;
    	
    }

    
}
