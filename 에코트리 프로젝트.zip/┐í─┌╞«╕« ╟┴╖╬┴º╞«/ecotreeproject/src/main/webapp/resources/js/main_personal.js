

function setCalculator(type) {
    if (type === 'electricity') {
    	console.log('Setting elec')
    	console.log(getType());
        document.getElementById('electricityCalculator').style.display = 'flex';
        document.getElementById('gasCalculator').style.display = 'none';
        document.getElementById('elec').style.display = 'flex';
        document.getElementById('gas').style.display = 'none';
        document.getElementById('goalCost').value= 0;
        document.getElementById('currentCost').value= 0;
    } else if (type === 'gas') {
    	console.log('Setting gas calculator');
    	console.log(getType());
        document.getElementById('electricityCalculator').style.display = 'none';
        document.getElementById('gasCalculator').style.display = 'flex';
        document.getElementById('elec').style.display = 'none';
        document.getElementById('gas').style.display = 'flex';
        document.getElementById('goalCostGas').value= 0;
        document.getElementById('currentCostGas').value= 0;
    }
}






                              